<?php

use App\Common;

?>

<?php $__env->startSection('content'); ?>
   <div class="event-form-container">
        <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        <div class="panel-body text-right">
            <h1 class='text-center' style="font-size:30px;">Add New Event</h1>

            <?php echo Form::model($event, [
                'route' => ['event.store'],
                'method' => 'POST',
                'enctype' => 'multipart/form-data',
                'id' => 'add_event',
                'onsubmit' => ' return confirmation()'
                ]); ?>


                <?php echo e(csrf_field()); ?>

                <div class="form-group row">
                    <?php echo Form::label('programme-title','Programme Name',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-7">
                        <?php echo Form::select('programme-title', Common::GetValidProgrammes(), null,['class' => 'form-control form-control-lg']
                                            ); ?>

                    </div>
                </div>
            
                <div class="form-group row">
                    <?php echo Form::label('name','Event Name',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-4">
						<?php echo Form::text('name', null,[
							'id' => 'event-name',
							'class' => 'form-control',
							'required' => 'true',
                            'pattern' => '[a-zA-Z0-9\s]+',
                            'placeholder' => 'Special characters are not allowed',
                            ]); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <?php echo Form::label('date','Event Date',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-3">
                    <?php echo Form::date('date', null,[
                                    'id' => 'event-date',
                                    'class' => 'form-control']); ?>

                    </div>
                </div>

                <div class="form-group row">
                    <?php echo Form::label('start_time','Event Start Time',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-3">
                    <?php echo Form::time('start_time', null,[
                                    'id' => 'from-event-time',
                                    'required'=>'true',
                                    'class' => 'form-control']); ?>

                    </div>
                </div>

                <div class="form-group row">
                    <?php echo Form::label('end_time','Event End Time',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-3">
                    <?php echo Form::time('end_time', null,[
                                    'id' => 'to-event-time',
                                    'required'=>'true',
                                    'class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <?php echo Form::label('venue','Event Venue',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-4">
                    <?php echo Form::text('venue', null,[
                                    'id' => 'event-venue',
                                    'required'=>'true',
                                    'class' => 'form-control']); ?>

                    </div>
                </div>

                <div class="form-group row">
                <?php echo Form::label('description','Event Description',['class' => 'control-label col-sm-3']); ?>

				<span class='required'>*</span>
                <div class="col-sm-4">
                <?php echo Form::textarea('description', null,[
                                'id' => 'event-description',
                                'required'=>'true',
                                'class' => 'form-control']); ?> 
                    </div>
                </div>

                <div class="form-group row">
                    <?php echo Form::label('created_by','Created by',['class' => 'control-label col-sm-3']); ?>

					<span class='required'>*</span>
                    <div class="col-sm-3">
                    <?php echo Form::text('created_by', null,[
                        'id' => 'created_by',
                        'required'=>'true',
                        'class' => 'form-control']); ?>

                    </div>
                </div>

                <div class="form-group row">
                    <?php echo Form::label('cover_image','Image',['class' => 'control-label col-sm-3']); ?>

                    <div class="col-sm-3">
                    <?php echo e(Form::file('cover_image')); ?>

                    </div>
                </div>

                <div class="form-group row text-center">
                    <div class="col-sm-offset-3 col-sm-6">
                        <input type="submit" class="btn btn-lg btn-primary">
                        <a href="<?php echo e(route('event.index')); ?>" class="btn btn-lg btn-danger">Cancel</a>
                    </div>
                </div>

                <?php echo Form::close(); ?>


                
        </div>
   </div>

   <script>
       function confirmation()
    {

        if (!confirm("Make sure that event details are correct, once you proceed after this stage you would not be able to go back." + "\n" + "\n" + "Are you sure you want to Proceed?" + "\n" ))
        {
          return false;
        }
        else
        {
          return true;
        }
    }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('event.master', ['title'=>'Add Event Event'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>