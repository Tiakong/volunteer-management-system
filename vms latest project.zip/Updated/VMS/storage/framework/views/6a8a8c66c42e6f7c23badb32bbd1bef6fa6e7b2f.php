<?php $__env->startSection('container'); ?>

<div class="container" >

 <label for="name" style="font-size:35px;margin:10px 0px 10px 100px;"><b>Areas you can contribute</b></label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Enterpreneurship</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Business</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Marketing</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Media</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> IT</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Multimedia</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Arts</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Dance</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Theatre</label>
 <br>
 <input type="checkbox" style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;"><label  style="margin-left:5px;font-size: 30px;font-family: Arial, Helvetica, sans-serif;"> Music</label>
 <br>

 <label for="name" style="font-size:35px;margin:10px 0px 10px 100px;"><b>Skill Proficiency</b></label>
 <br>
 <label for="name" style="font-size:20px;margin-left:280px;"><b>Very Good</b></label>
 <label for="name" style="font-size:20px;margin-left:30px;"><b> Good</b></label>
 <label for="name" style="font-size:20px;margin-left:30px;"><b> Fair</b></label>
 <label for="name" style="font-size:20px;margin-left:30px;"><b> Poor</b></label>
 <label for="name" style="font-size:20px;margin-left:30px;"><b> Very Poor</b></label>
 <label for="name" style="font-size:20px;margin-left:30px;"><b> Don't know this language</b></label>
 <br>
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>Language</b></label>
 <form action="">
 <br>
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- English</b></label>
 <input type="radio" name="size"value="s"style="margin-left:110px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

 <form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Mandarin</b></label>
 <input type="radio" name="size"value="s"style="margin-left:80px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Hindi</b></label>
 <input type="radio" name="size"value="s"style="margin-left:130px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Malay</b></label>
 <input type="radio" name="size"value="s"style="margin-left:123px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Burnese</b></label>
 <input type="radio" name="size"value="s"style="margin-left:100px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Bengali</b></label>
 <input type="radio" name="size"value="s"style="margin-left:106px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Urdu</b></label>
 <input type="radio" name="size"value="s"style="margin-left:136px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Vietnamese</b></label>
 <input type="radio" name="size"value="s"style="margin-left:58px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Thai</b></label>
 <input type="radio" name="size"value="s"style="margin-left:144px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:90px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:55px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:50px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:70px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s" style="margin-left:170px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<br>
<label for="name" style="font-size:20px;margin-left:290px;"><b>Expert</b></label>
<label for="name" style="font-size:20px;margin-left:80px;"><b> Intermediate</b></label>
<label for="name" style="font-size:20px;margin-left:80px;"><b> Beginner</b></label>
<label for="name" style="font-size:20px;margin-left:80px;"><b> Don't know this skill</b></label>
<br>
<label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>Microsoft</b></label>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Word</b></label>
 <input type="radio" name="size"value="s"style="margin-left:130px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Excel</b></label>
 <input type="radio" name="size"value="s"style="margin-left:135px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Power Point</b></label>
 <input type="radio" name="size"value="s"style="margin-left:53px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<br>
<label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>Programming</b></label>
<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- C++</b></label>
 <input type="radio" name="size"value="s"style="margin-left:145px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Java Script</b></label>
 <input type="radio" name="size"value="s"style="margin-left:69px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Phyton</b></label>
 <input type="radio" name="size"value="s"style="margin-left:112px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- PHP</b></label>
 <input type="radio" name="size"value="s"style="margin-left:145px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- SQL</b></label>
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<br>
<label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>Design</b></label>
<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Photoshop</b></label>
 <input type="radio" name="size"value="s"style="margin-left:69px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- Illustrator</b></label>
 <input type="radio" name="size"value="s"style="margin-left:79px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- PremiumPro</b></label>
 <input type="radio" name="size"value="s"style="margin-left:48px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<br>
<label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>Emgineering Design</b></label>
<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- AutoCad</b></label>
 <input type="radio" name="size"value="s"style="margin-left:92px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<form action="">
 <label for="name" style="font-size:25px;margin:10px 0px 10px 100px;"><b>- SolidWorks</b></label>
 <input type="radio" name="size"value="s"style="margin-left:60px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:150px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:160px; left: 0;height: 20px;width: 20px;background-color: #eee;">
 <input type="radio" name="size"value="s"style="margin-left:180px; left: 0;height: 20px;width: 20px;background-color: #eee;">
</form>

<br>
<br>
<br>

<input type=button onClick="location.href='/register4'" class="registerbtn" style="background-color: rgb(13, 106, 228);
                                                  color: white;
                                                  width:300px;
                                                    height:60px;
                                                    font-size:30px;
                                                    margin-left:100px;
                                                    font-family: Arial, Helvetica, sans-serif" value='Submit'>
<button type="cancel" onClick="location.href='register2'"class="cancelbtn" style="background-color: 	#CD5C5C;
color: white;
width:300px;
height:60px;
font-size:30px;
margin-right:100px;
float:right;
font-family: Arial, Helvetica, sans-serif">Cancel</button>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', ['title'=>'Register'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>