<?php
use App\Common;
?>


<?php $__env->startSection('content'); ?>
<div class="text-center col-sm-12">
	<br/>
	<?php echo $__env->make('common.show-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<br/>
	<form name='submitForm' class="text-right border border-light p-3" method="post" action="<?php echo e(url('notification/create')); ?>" accept-charset="UTF-8">
		<?php echo e(csrf_field()); ?>

		<div class="form-group row">
			<div class='col-sm-2 p-2'>
				<?php echo Form::label('notification-tite', 'Title', [
					'class' => 'control-label',
				]); ?>

				<span class='required'>*</span>
			</div>
			<div class="col-sm-10">
				<input type="text" name="title" class="form-control mb-4" placeholder="Notification Title" />
			</div>
		</div>
		<div class="form-group row">
			<div class='col-sm-2 p-2'>
				<?php echo Form::label('notification-description', 'Description', [
					'class' => 'control-label',
				]); ?>

				<span class='required'>*</span>
			</div>
			<div class="col-sm-10">
				<textarea id='description' type="text" name="description" class="form-control mb-4" placeholder="Notification Description" rows='6'></textarea>
			</div>
		</div>
		<div class="form-group row">
			<div class='col-sm-2 p-2'>
				<?php echo Form::label('category-label', 'Category', [
					'class' => 'control-label',
				]); ?>

				<span class='required'>*</span>
			</div>
			<div class="col-sm-10">
				<?php echo Form::select('category', Common::$NotificationCategory, 1, [
					'id'	=> 'preset',
					'name'	=> 'category',
					'class' => 'form-control form-control-lg',
					'onchange' => 'SetDescription(this)',
				]); ?>

			</div>
		</div>
		<div class="form-group row" style='margin-left:120px'>
			<input name='url-link' type='text' style='margin:0 4px;' class='col-sm-6' placeholder='URL Link'/>
			<input name='url-title' type='text' style='margin:0 4px;' class='col-sm-3' placeholder='Title of the link'/>
			<input onclick='InsertLink(this)' type='button' style='margin:0 4px;' class='btn btn-lg btn-primary' value='Insert Link' />
			<a id='preview-link' class='p-2' href="" target="_blank"></a>
		</div>
		<div class="form-group row" style='margin-left:120px'>
		<div id='radioSelection' class="border border-light p-3">
			<span class='required'>*</span>
			<div id='notifType' class="form-group col-sm-12">
				<div class="radio-panel form-group row" >
					<?php echo Form::radio('type', 1, false); ?>

					<label style='padding: 5px 10px 0px 0px;'>Broadcast this notification</label>
				</div>
				<div id='defaultRadio' class="radio-panel form-group row">
					<?php echo Form::radio('type', 2, true); ?>

					<label style='padding: 5px 10px 0px 0px;'>Send to all volunteers</label>
				</div>
				<div id='selection3' class="radio-panel form-group row" >
					<?php echo Form::radio('type', 3, false); ?>

					<label style='padding: 5px 10px 0px 0px;'>Specify volunteer</label>
				</div>
				<div id='volCriteria' hidden class="text-center">
					<button type="button" title='Pop up search tab' class='btn btn-primary'><b>Search Volunteer</b></button>
				</div>
			</div>
		</div>
		<div id='searchVolunteerPanel' class="text-center p-3 col-sm-9">
			<div class='row'>
				<label>To search volunteer, click <a href="<?php echo e(route('admin.searchVolunteer')); ?>" target='_blank'>here</a></label>.
			</div>
			<br/>
			Matching Volunteer: <span id="matchCount">0</span>
			<div id='programmeName' title='Narrow the events'>
				<div class='card-body row'>
					<?php echo Form::label('programme-name', 'Programme', [
						'class' => 'control-label col-sm-3 p-2',
					]); ?>

					<div class="col-sm-9">
						<?php echo Form::select('programme-title', Common::GetProgrammes(), null, [
							'id'	=> 'programme_code',
							'class' => 'form-control form-control-lg dynamic',
							'placeholder' => '- ',
						]); ?>

					</div>
				</div>
			</div>
			<div id='eventName' title='Volunteer that reserved/participated for this event'>
				<div class='card-body row'>
					<?php echo Form::label('event-name', 'Reserved In Event', [
						'class' => 'control-label form-control-lg col-sm-3 p-2',
					]); ?>

					<div class="col-sm-9">
						<select id='event_title' class='form-control form-control-lg' name='event_tite'>
							<option selected="selected" value=""> - </option>
						</select>
					</div>
				</div>
			</div>
			<div id="date" title='Narrow the events'>
				<div class="card-body row">
					<?php echo Form::label('date-from', 'From', [
						'class' => 'control-label form-control-lg col-sm-3 p-2',
					]); ?>

					<div class='col-sm-9'>
						<input type="date" id='date_from' value='<?php echo date('Y')."-01-01"?>' class='form-control dynamic' name='date' style='width:100%' />
					</div>
				</div>
				<div class="card-body row">
					<?php echo Form::label('date-to', 'To', [
						'class' => 'control-label form-control-lg col-sm-3 p-2',
					]); ?>

					<div class='col-sm-9'>
						<input type="date" id='date_to' value='<?php echo date('Y')."-12-31"?>' onchange='console.log(this.value)' class='form-control dynamic' name='date' style='width:100%' />
					</div>
				</div>
			</div>
		</div>

		</div>
		<div class="form-group row">
			<div class='col-sm-2 p-2'>
				<?php echo Form::label('employee-name', 'Created by', [
					'class' => 'control-label',
				]); ?>

				<span class='required'>*</span>
			</div>
			<div class="col-sm-5">
				<input type="text" name="created_by" class="form-control mb-4" placeholder="Employee name/nickname" />
			</div>
		</div>
	</form>
	<div class="form-group row text-center">
                    <div class="col-sm-offset-3 col-sm-6">
			
					<a>
				<button type='button' class="btn btn-lg btn-info" onclick="CopyEmailAddress()"><i class='fa fa-envelope'></i> Copy Email Addresses</button>
			</a>
			<a>
				<button type='button' class="btn btn-lg btn-primary" onclick='SubmitForm()' ><i class='fa fa-check-square-o'></i> Submit</button>
			</a>
			<a href="<?php echo e(route('notification.index')); ?>">
				<button class="btn btn-lg btn-danger" onclick='return confirm("Are you sure you want to leave this page?\nAll changes will not be saved.")'><i class='fa fa-reply'></i> Back</button>
			</a>
			
		</div>
	</div>
</div>

<script>
var HasCopyEmail = false;

$(document).ready(function(){
	$('.radio-panel').click(function(){
		SelectRadio(this);
	});

	$('.dynamic').change( function(){
		var code = document.getElementById('programme_code').value;
		var date_from = document.getElementById('date_from').value;
		var date_to = document.getElementById('date_to').value;
		if(code)
		{
			SendRequest(
				'<?php echo route('query.get-events') ?>',
				{
					'code':code, 
					'date_from':date_from,
					'date_to':date_to
				},
				!(date_from.charAt(0)==0 || date_to.charAt(0)==0),
				updateEventOption
			);
		}
		else
		{
			var select = document.getElementById('event_title');
			select.innerHTML = '<option selected="selected" value=""> - </option>';
		}
	});
	
	$("#event_title").change(function()
	{
		//Show volunteer name list
		SendRequest(
			"<?php echo route("query.VE_getVolunteers")?>",
			{
				"eid" : $(this).val()
			},
			true,
			function(r){
				$("#matchCount").get(0).innerHTML = r.length;
			}
		);
	});
	
	function updateEventOption(events){
		var select = document.getElementById('event_title');
		if(events.length>0)
		{
			select.innerHTML = '<option selected="selected" value=""> - </option>';
			events.forEach(e=>{
				select.innerHTML += '<option value='+e['eid']+'>'+e['name']+'</option>'
			});
		}
		else
		{
			select.innerHTML = '<option selected="selected" value=""> No matching result </option>';
		}
		$("#matchCount").get(0).innerHTML = "0";
	}
	
	SelectRadio($('#defaultRadio').get(0));
});

function InsertLink(btn)
{
	var urlLink = $('input[name="url-link"]').get(0).value;
	var urlTitle = $('input[name="url-title"]').get(0).value;
	var description = $('textarea[name="description"]').get(0);
	var preview_link = $('#preview-link').get(0);
	if(urlLink=='' || urlTitle=='')
	{
		alert('Please enter the url link and url title.');
		return;
	}
	
	description.value += '<a href="'+urlLink+'" target="_blank">' + urlTitle + '</a>';
	
	preview_link.href = urlLink;
	preview_link.innerHTML = urlTitle;
}

function SelectRadio(dom)
{
	dom.parentNode.querySelectorAll('div').forEach(e=>e.classList.remove('select'));
	var radioSelection = document.getElementById('radioSelection');
	radioSelection.querySelectorAll("input[type='radio']").forEach(e=>{e.parentElement.classList.remove('bg-info');});
	dom.querySelector("input[type='radio']").checked = true;
	dom.classList.add('select');
	if(dom.id=="selection3")
		$('#searchVolunteerPanel').attr('hidden', false);
	else
		$('#searchVolunteerPanel').attr('hidden', true);
}

function CopyEmailAddress()
{
	var type=1;
	var elements = document.getElementsByName("type");
	for(var i=0; i<elements.length; i++){
		if(elements[i].checked){
			type = i+1;
			break;
		}
	};
	
	var eid = document.getElementById('event_title').value;
	SendRequest(
		"<?php echo route('query.get-email')?>",
		{
			"type"		:type,
			"eid":eid,
		},
		true,
		function(str){
			HasCopyEmail = true;
			const el = document.createElement('textarea');
			el.value = str;
			document.body.appendChild(el);
			el.select();
			document.execCommand('copy');
			document.body.removeChild(el);
			
			alert("Email addresses were copied.\nPress Ctrl+V to paste the email addresses.");
		}

	);
}
function SubmitForm()
{
	var str = "Confirm sending notifications?" + (HasCopyEmail?'':'\nYou have not yet copy the email address.');
	if( confirm(str) )
	{
		let fields = ["event_title", "programme_code", "date_from", "date_to"];
		
		fields.forEach(function(f){
			const field = document.getElementById(f).value;
			const hiddenInput = document.createElement("input");
			hiddenInput.type = "hidden";
			hiddenInput.name = f;
			hiddenInput.value = field;
			console.log(hiddenInput.value);
			document.submitForm.appendChild(hiddenInput);
		})
		
		document.submitForm.submit();
		
	}
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('notification.master', ['title'=>'Send Notification'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>