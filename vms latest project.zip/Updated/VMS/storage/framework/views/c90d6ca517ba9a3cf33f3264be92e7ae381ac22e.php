<?php $__env->startSection('container'); ?>

  <div class="container" >

   <label for="name" style="font-size: 30px;
   margin:10px 0px 10px 100px;"><b>Full Name</b></label>
   <input type="text" style= "width:80%;
   height: 50px;
   margin-left:100px;
   padding:10px 20px;
   border: 1px solid blue;
   border-radius: 4px;
   font-size:20px;
   box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter full name" name="name" required>

 <label for="gender" style="font-size: 30px;
 margin:10px 0px 10px 100px;"><b>Gender</b></label>
 <input type="text" style= "width:80%;
 height: 50px;
 margin-left:100px;
 padding:10px 20px;
 border: 1px solid blue;
 border-radius: 4px;
 font-size:20px;
 box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter gender" name="gender" required>

<label for="nationality" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Nationality</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;;"placeholder="Enter nationality" name="nationality" required>

<label for="age" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Age</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter age" name="age" required>

<label for="no" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Contact No.</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter contact no." name="no" required>

<label for="email" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Email</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter Email" name="email" required>

<label for="address" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Address</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter address" name="address" required>

<label for="edclvl" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Education Level</b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter education level" name="edclvl" required>

<label for="occupation" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Occupation </b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue;"placeholder="Enter occupation" name="occupation" required>

<label style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>T-shirt Size </b></label>
<input type="radio" style="font-size: 30px;font-family: Arial, Helvetica, sans-serif;">  S
<input type="radio" style="font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> M
<input type="radio" style="font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> L
<input type="radio" style="font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> XL

<br>
<br>

<label style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Experinced as any volunteer before? </b></label>
<input type="radio" style="font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1">Yes
<input type="radio" style="font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1">No

<br>
</br>


<label for="yes" style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>If Yes Please State </b></label>
<input type="text" style= "width:80%;
height: 50px;
margin-left:100px;
padding:10px 20px;
border: 1px solid blue;
border-radius: 4px;
font-size:20px;
box-shadow: 0px 0px 15px 0px lightblue";placeholder="If yes please state" name="yes" required>

<label style="font-size: 30px;
margin:10px 0px 10px 100px;"><b>Programmes That You Interested In (Can Choose More Than 1)</b></label> <br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> Make a Difference(M.A.D)(all year)
<br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> Self-empowering nd Tnstition Employability Program(S.T.E.P)(March-June)
<br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> Youth Enterpreneurship Programme(Y.E.P)(December-April)
<br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> Change Makers' Project (CMP)(Octobe-November)
<br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> Tutor a Refugee Child (Weekly)
<br>
<br>
<input type="radio" style="margin-left:100px;
font-size: 20px;font-family: Arial, Helvetica, sans-serif;" name="radio" value="Radio 1"> For now on,I'm not sure which programme that I interested with
<br>
<br>

<input type=button onClick="location.href='/register3'" class="registerbtn btn btn-primary" style="background-color: rgb(13, 106, 228);
                                                  color: white;
                                                  width:300px;
                                                    height:60px;
                                                    font-size:30px;
                                                    margin-left:100px;
                                                    font-family: Arial, Helvetica, sans-serif" value='Next'>
<button type="cancel" onClick="location.href='register'"class="cancelbtn btn btn-primary" style="background-color: 	#CD5C5C;
color: white;
width:300px;
height:60px;
font-size:30px;
margin-right:100px;
float:right;
font-family: Arial, Helvetica, sans-serif">Cancel</button>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', ['title'=>'Register'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>