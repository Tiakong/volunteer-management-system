<?php
use Carbon\Carbon;
?>


<?php $__env->startSection('container'); ?>
<?php if(Session::get('authority')=='volunteer' || Session::get('authority')=='admin'): ?>
<div class="content">
	<div class="left-section">
		<?php if(Session::get('authority')=='admin'): ?>
		<!-- Active & Non Active Volunteer Count -->
		<div class="main-section">
			<div style='width:400px'>
				<div>
					<h1><i class="fa fa-address-book-o" style="margin-right: 10px;color:black;"></i>Volunteers Statistic</h1>
					<table class="table table-stripped table-bordered">
						<col width="80%">
						<col width="20%">
						<thead class='thead-dark'>
							<tr>
								<th>Number of Volunteers</th>
								<td><?php echo e($volunteer_count); ?></td>
							</tr>
							<tr>
								<th>Active Volunteers</th>
								<td><?php echo e($active_volunteer_count); ?></td>
							</tr>
							<tr>
								<th>New Volunteer Registered this month</th>
								<td><?php echo e($new_volunteer_this_month); ?></td>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<!-- Next upcoming event -->
		<div class="main-section">
			<div class="ranking-section">
				<div>
					<h1><i class="fa fa-list-alt" style="margin-right: 10px;color:black;"></i>Next Upcoming Event</h1>
					<table class="table table-stripped table-bordered">
						<col width="10%">
						<col width="28%">
						<col width="18%">
						<col width="18%">
						<col width="16%">
						<col width="15%">
						<thead class='thead-dark'>
							<tr>
								<th>Programme</th>
								<th>Event Name</th>
								<th>Date</th>
								<th>Time</th>
								<th>Day Left</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php if(count($next_events)==0): ?>
							<tr>
								<th colspan=4>No event</th>
							</tr>
							<?php else: ?>
								<?php $__currentLoopData = $next_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th><?php echo e($next_event->code); ?></th>
								<th><?php echo e($next_event->name); ?></th>
								<th><?php echo e($next_event->date); ?></th>
								<th><?php echo e(Carbon::parse($next_event->start_time)->format('h:i a')); ?> <br> ~ <br> <?php echo e(Carbon::parse($next_event->end_time)->format('h:i a')); ?></th>
								<th><?php echo e($next_event->date_diff); ?></th>
								<th><a href="<?php echo e(route('event.show-detail', $next_event->eid)); ?>">See More</a></th>
							</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div class='right-section text-center'>
        <div class="ranking-section">
			<div class="main-section-content">
				<!-- Life time serving -->
				<div>
					<h1><i class="fa fa-trophy" style="margin-right: 10px;color:black;"></i>Cybercare Leaderboard</h1>
					<table class='table table-stripped table-bordered'>
						<col width="">
						<thead class='thead-dark'>
							<tr>
								<th>Ranking</th>
								<th>Name</th>
								<th>Occupation</th>
								<th>Total Serve hour</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $volunteer_acc_serve_hour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class='text-center'><?php echo e($loop->index+1); ?></td>
								<td><?php echo e($row->name); ?></td>
								<td><?php echo e($row->occupation); ?></td>
								<td class='text-center'><?php echo e($row->total_serve_hour); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				
				<!-- Annual serving -->
				<div>
					<h1><i class="fa fa-trophy" style="margin-right: 	10px;color:black;"></i>Annual Leaderboard(<?php echo e(date('Y')); ?>)</h1>
					<table class='table table-stripped table-bordered'>
						<col width="">
						<thead class='thead-dark'>
							<tr>
								<th>Ranking</th>
								<th>Name</th>
								<th>Occupation</th>
								<th>Total Serve hour</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $volunteer_ann_serve_hour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class='text-center'><?php echo e($loop->index+1); ?></td>
								<td><?php echo e($row->name); ?></td>
								<td><?php echo e($row->occupation); ?></td>
								<td class='text-center'><?php echo e($row->total_serve_hour); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php else: ?>
<script>
 window.location.href = '<?php echo e(route("auth")); ?>';
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', ['title'=>'Welcome to Volunteer Management System'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>