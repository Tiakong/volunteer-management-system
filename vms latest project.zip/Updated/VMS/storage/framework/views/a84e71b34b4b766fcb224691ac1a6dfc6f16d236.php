<?php
use App\Common;
?>



<?php $__env->startSection('content'); ?>
<div class='text-center col-sm-12'>
	<br/>
	<?php echo $__env->make('common.show-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<br/>
	<?php if(\Session::get('authority') == 'admin'): ?>
	<a href='<?php echo e(route("notification.create")); ?>'><button class='btn btn-lg btn-primary'><i class="fa fa-envelope" aria-hidden="true"></i> Send Notification</button></a>
	<?php endif; ?>
	<br/>
	<!--Broadcast Notification-->
	<div class='card text-left' style="height:300px;overflow-y:scroll;overflow-x:hidden;border:1px solid black;margin-top:10px;display:block;">
		<div class='row card-body'>
			<h3 class='text-center' style='margin:0 auto;margin-top:10px;margin-bottom:15px;'>Broadcast Notification</h3>
			<table class="table table-striped table-bordered text-left disable-highlight">
				<col width="5%">
				<col width="70%">
				<col width="25%">
				<?php $__currentLoopData = $broadcastnotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<thead class="black white-text notification-title">
					<?php if(Common::$NotificationCategory[$row->category]=="Urgent"): ?>
				<tr class='Urgent'>
					<td class='text-center'><?php echo e($loop->index+1+($notifications->currentPage()-1)*$notification_per_page); ?></td>
					<td>
						<?php if(Session::get('authority')=='volunteer' && $row->read_at==null ): ?>
							<span class='tag New'>NEW</span>
						<?php endif; ?>
					<?php echo e($row->title); ?>

					</td>
					<td class='text-center'><?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y')); ?></td>
				</tr>
				<?php else: ?>
				<tr>
					<td class='text-center'><?php echo e($loop->index+1+($notifications->currentPage()-1)*$notification_per_page); ?></td>
					<td>
						<?php if(Session::get('authority')=='volunteer' && $row->read_at==null ): ?>
							<span class='tag New'>NEW</span>
						<?php endif; ?>
						<?php if(Common::$NotificationCategory[$row->category]!="Normal" ): ?>
							<span class='tag <?php echo e(Common::$NotificationCategory[$row->category]); ?>'><?php echo e(Common::$NotificationCategory[$row->category]); ?></span>
						<?php endif; ?>
						<?php echo e($row->title); ?>

					</td>
					<td class='text-center'><?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y')); ?></td>
				</tr>
				<?php endif; ?>
				</thead>
				<tbody class='notification-description'>
					<tr>
						<td colspan=3>
							<pre><?php echo $row->description ?></pre>
						</td>
					</tr>
					<tr>
						<td colspan=2>Created by <?php echo e($row->created_by); ?></td>
						<td class='text-center'><a href="<?php echo e(route('notification.show', $row->nid)); ?>">See More</a></td>
					</tr>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
	
	<!--Normal Notification-->
	<div class='p-5 text-left' style='display:block;'>
		<?php echo e($notifications->links('common.pagination')); ?>

		<table class="notification-table table table-bordered disable-highlight">
			<col width="5%">
			<col width="75%">
			<col width="20%">
			<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<thead class="white-text notification-title" id='<?php echo e($row->nid); ?>'>
				<?php if(Common::$NotificationCategory[$row->category]=="Urgent"): ?>
				<tr class='Urgent'>
					<td class='text-center'><?php echo e($loop->index+1+($notifications->currentPage()-1)*$notification_per_page); ?></td>
					<td>
						<?php if(Session::get('authority')=='volunteer' && $row->read_at==null ): ?>
							<span class='tag New'>NEW</span>
						<?php endif; ?>
					<?php echo e($row->title); ?>

					</td>
					<td class='text-center'><?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y')); ?></td>
				</tr>
				<?php else: ?>
				<tr>
					<td class='text-center'><?php echo e($loop->index+1+($notifications->currentPage()-1)*$notification_per_page); ?></td>
					<td>
						<?php if(Session::get('authority')=='volunteer' && $row->read_at==null ): ?>
							<span class='tag New'>NEW</span>
						<?php endif; ?>
						<?php if(Common::$NotificationCategory[$row->category]!="Normal" ): ?>
							<span class='tag <?php echo e(Common::$NotificationCategory[$row->category]); ?>'><?php echo e(Common::$NotificationCategory[$row->category]); ?></span>
						<?php endif; ?>
						<?php echo e($row->title); ?>

					</td>
					<td class='text-center'><?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y')); ?></td>
				</tr>
				<?php endif; ?>
			</thead>
			<tbody class='notification-description'>
				<tr>
					<td colspan=3>
						<pre><?php echo $row->description ?></pre>
					</td>
				</tr>
				<tr>
					<td colspan=2>Created by <?php echo e($row->created_by); ?></td>
					<td class='text-center'><a href="<?php echo e(route('notification.show', $row->nid)); ?>">See More</a></td>
				</tr>
			</tbody>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
		<?php echo e($notifications->links('common.pagination')); ?>

	</div>
</div>

<script>
$('.notification-title').click(function(){
	$(this).next('.notification-description').toggleClass('row-active');
	//$(this).next('.notification-description').slideToggle('fast');
	
	let nid = $(this).prop('id');
	
	if(<?php echo Session::get('authority')=='volunteer'?'true':'false' ?>)
	{
		SendRequest(
			"<?php echo route('notification.read')?>",
			{
				'nid' : nid
			},
			true,
			function(){
				$('thead#'+nid).find('.New').remove();
			}
		);
	}
	
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('notification.master', ['title'=>"Notification Center"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>