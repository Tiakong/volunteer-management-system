<?php

use App\Common;

 ?>

 
 <?php $__env->startSection('content'); ?>


<div class="program-table">
                <table>
                    <tr>
                        <td><b>Name:</b></td>
                        <td>
                          <div>
                            <?php echo e($programme->name); ?>

                          </div>
                        </td>
                    </tr>

                    <tr>
                        <td><b>Code:</b></td>
                        <td>
                          <div>
                            <?php echo e($programme->code); ?>

                          </div>
                        </td>
                    </tr>

                    <tr>
                        <td><b>Duration:</b></td>
                        <td><div>  <?php echo e(Common::$Month[$programme->start_month]); ?> <?php echo " " ?><?php echo e($programme->start_year); ?>  <?php echo "-" ?>  <?php echo e(Common::$Month[$programme->end_month]); ?><?php echo " " ?><?php echo e($programme->end_year); ?>

                        </div></td>
                    </tr>

                    <tr>
                        <td><b>Venue:</b></td>
                        <td>
                          <div>
                            <?php echo e($programme->venue); ?>

                          </div>
                        </td>
                    </tr>

                    <tr>
                        <td><b>Target: </b></td>
                        <td>
                          <div>
                            <?php echo e($programme->target); ?>

                          </div>
                        </td>
                    </tr>

                    <tr>
                        <td><b>Contact: </b></td>
                        <td>
                          <div>
                            <?php echo e($programme->contact); ?>

                          </div>
                        </td>
                    </tr>

                    <tr>
                        <td><b>Description:</b></td>
                        <td>
                          <div>
                            <?php echo e($programme->description); ?>

                          </div>
                        </td>
                    </tr>
                    <tr>

                    <tr>
                        <td><b>Created By: </b></td>
                        <td>
                          <div>
                            <?php echo e($programme->created_by); ?>

                          </div>
                        </td>
                    </tr>
                    <tr>
                      
                    </tr>
                    <td><b>Supporting Partners:</b></td>
                    <td>
                    <?php $__currentLoopData = $programmeImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Storage::disk('public')->exists('cover_image/'.$image->filename)): ?>
                        
                            <img src ="/storage/cover_image/<?php echo e($image->filename); ?>" width="164" height="164"  style="margin:10px;">

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <tr>
                      <td></td>
                      <td>
                      <div class="form-group_row">
              <div class="col-sm-offset-3 col-sm-6">
                  <a href='<?php echo e(route("programme.edit", $programme->pid)); ?>'>
                    <button class='btn btn-lg btn-success'><b><i class='fa fa-edit'></i> Edit</b></button></a>
                
                  
                  <a href='<?php echo e(route("programme.delete", $programme->pid)); ?>' onclick="return confirmation()"><button class='btn btn-lg btn-danger'><b><i class='fa fa-remove'></i> Delete </b></button></a>
                  </button>
                  </div>
                  </div>
                          </td>
                    </tr>
                </table>

</div>

<script>

function confirmation()
    {

        if (!confirm("Are you sure want to delete this programme? You are not be able to recover this programme details after deleted it." + "\n" + "\n" + "Are you sure you want to Proceed?" + "\n" ))
        {
          return false;
        }
        else
        {
          return true;
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('programme.master', ['title'=>'View Programme Details'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>