

<div class="navbar">
	<a class="logo"><img src="<?php echo e(asset('pics/logo.png')); ?>" class="imgsize"></a>
	<div>
		<ul class="navlist navigation-bar">
			<li><a href=".sec01">Section 01</a></li>
			<li><a href=".sec01">Section 01</a></li>
			<li><a href=".sec01">Section 01</a></li>
			<li><a href=".sec02">Section 02</a></li>
			<li><a href=".sec03">Section 03</a></li>
			<li><a href=".sec04">Section 04</a></li>
		</ul>
	</div>
</div>