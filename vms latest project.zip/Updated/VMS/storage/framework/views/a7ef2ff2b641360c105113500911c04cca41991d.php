<?php $__env->startSection('content'); ?>

<table class='table table-bordered table-striped'>
	<col width="5%">
	<col width="18%">
	<col width="5%">
	<col width="15%">
	<col width="15%">
	<col width="9%">
	<col width="28%">
	<col width="10%">
	<thead class='thead-dark'>
        <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Serve Hour</th>
            <th>Remark</th>
            <th>Status</th>
        </tr>
    </thead>
	<?php if(count($volunteers)>0): ?>
	<tbody>
        <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><?php echo e($volunteer->name); ?></td>
            <td class='text-center'><?php echo e($volunteer->gender); ?></td>
            <td><?php echo e($volunteer->contact_no); ?></td>
            <td><?php echo e($volunteer->email); ?></td>
            <td class='text-center'><?php echo e($volunteer->serve_hour); ?></td>
            <td><?php echo e($volunteer->event_remark); ?></td>
            <td class='text-center'><?php echo e($volunteer->status); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
	<?php else: ?>
	<tr>
		<td colspan='8'>No volunteers had registered this event yet.</td>
	</tr>
	<?php endif; ?>
</table>

<div class="form-group row text-center">
              <div class="col-sm-offset-3 col-sm-6">
		<a href="<?php echo e(route('volunteer_event.create',['id'=>$eid])); ?>">
			<button class="btn btn-lg btn-primary"><i class='fa fa-edit'></i> Edit</button>
		</a>
		<a href="<?php echo e(route('event.show-detail',['id'=>$eid])); ?>">
			<button class="btn btn-lg btn-danger"><i class='fa fa-reply'></i> Back</button>
		</a>
	</div>
</div>


<script>
var msg = '<?php echo e(Session::get('alert')); ?>';
var exist = '<?php echo e(Session::has('alert')); ?>';
if(exist){
	alert(msg);
}



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('event.master', ['title'=>'Volunteers\' Enrollment'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>