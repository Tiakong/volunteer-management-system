
<div class="program-sidebar">
            <!-- this must change to loop for dynamic program list generation-->
            <ul class="program-box">
                <li>MAD</li>
                <li>STEP</li>
                <li>YEP</li>
            </ul>

            <div class="event-radio-box">
            <form style="padding:10px;"  action="">
                <input type="radio" id="event1" onclick="eventForm()" name="event"  value="ReservedEvent"> Reserved Event<br><br>
                <input type="radio" id="event2" onclick="eventForm()" name="event"  value="AvailableEvent"> Available Event<br>
            </form>
            </div>
        </div>