$(document).ready(function(){

	$('.side-bar-button').click(function(){
		$('.bg-modal').css('display', 'flex');
	});

	$('#sticky-bar-button').click(function(){
		$('.bg-modal').css('display', 'flex');
	});

	$('.closelogo').click(function(){
		$('.bg-modal').css('display', 'none');
	});
	
});