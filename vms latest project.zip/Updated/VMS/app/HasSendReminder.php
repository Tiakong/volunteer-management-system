<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HasSendReminder extends Model
{
	protected $primaryKey = 'eid';
	protected $table = 'has_send_reminder';
    protected $fillable = [
		'eid'
	];
}
