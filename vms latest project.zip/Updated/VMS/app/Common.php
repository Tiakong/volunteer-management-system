<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Event;
use App\Programme;

class Common
{	
	public static $DAY_TO_CONSIDER_INACTIVE = 100;

	public static $Month = [
		1 => 'January',
		2 => 'February',
		3 => 'March',
		4 => 'April',
		5 => 'May',
		6 => 'June',
		7 => 'July',
		8 => 'August',
		9 => 'September',
		10 => 'October',
		11 => 'November',
		12 => 'December',
	];
	
	public static $volunteerGender = [
		'M'	=> 'Male',
		'F'	=> 'Female',
	];
	
	public static $educationLvl = [
		'1' => 'Primary School',
		'2' => 'Secondary School',
		'3' => 'Pre-University',
		'4' => 'Bachelor Degree',
		'5' => 'Master Degree',
		'6' => 'Doctoral Degree',
	];

	public static $tShirtSize =[
		'1'=> 'S',
		'2'=> 'M',
		'3'=> 'L',
		'4'=> 'XL',
	];
	public static $Strength=[
		'0'=>'Limited',
		'1'=>'Basic',
		'2'=>'Functional',
		'3'=>'Proficient',
		'4'=>'Excellent',
	];
	public static $Proficient=[
		'0'=>'No idea about this skill',
		'1'=>'Beginner',
		'2'=>'Intermediate',
		'3'=>'Expert',
	];
	
	public static $SkillsetsShortform = ['langEN', 'langZH', 'langMS', 'langHI', 'mcrExcel', 'mcrPowerPoint', 'pgrCpp', 'pgrJs', 'pgrPhp', 'pgrPython', 'pgrSql', 'dsgPhotoshop', 'dsgIllustrator', 'dsgPremiumPro', 'edgnAutocad', 'edgnSolidWorks', 'dgtMultimedia', 'dgtSocialMedia', 'dgtIT', 'ctvArt', 'ctvDraw', 'ctvDance', 'ctvThretre', 'ctvMusic', 'cmmMarket', 'cmmMedia', 'cmmPresentation','funding','branding','business', 'entrepreneurship'];
	
	public static $Skillsets = [
		'Microsoft' => [
			'mcrWord'			=>"Microsoft Word",
			'mcrExcel'			=>"Excel",
			'mcrPowerPoint'		=>"Power Point",
		],
		'Programing'=>[
			'pgrCpp'			=>"C++",
			'pgrJs' 			=>"Java Script",
			'pgrPhp'			=>"Php",
			'pgrPython'			=>"Python",
			'pgrSql'			=>"SQL",
		],
		'Design'=>[
			'dsgPhotoshop'		=>"Photoshop",
			'dsgIllustrator'	=>"Illustrator",
			'dsgPremiumPro'		=>"Premium Pro",
		],
		'Engineering Design'=>[
			'edgnAutocad'		=>"Auto CAD",
			'edgnSolidWorks'	=>"Solid Works",
		],
	];
	public static $Language = [
		'langEN'	=> "English",
		'langMS'	=> "Malay",
		'langZH'	=> "Mandarin",
		'langHI'	=> "Hindi",
	];
	
	public static $ContributeArea = [
		'Digital'	=>	[
			'dgtMultimedia' => 'Multimedia',
			'dgtSocialMedia'=> 'Social Media',
			'dgtIT' 		=> 'IT',
		],
		'Creative'	=> [
			'ctvArt'		=> 'Art',
			'ctvDraw'		=> 'Drawing',
			'ctvDance'		=> 'Dance',
			'ctvThretre'	=> 'Threter',
			'ctvMusic'		=> 'Music',
		],
		'Communication' => [
			'cmmMarket'			=>	'Market',
			'cmmMedia'			=>	'Media',
			'cmmPresentation'	=> 'Presentation',
		],
		'entrepreneurship'	=>	'Entrepreneurship',
		'business'			=>	'Business',
		'funding'			=>	'Funding',
		'branding'			=>	'Branding',
	];

	public static $SubContributeArea = [
		'Digital'	=>	[
			'dgtMultimedia' => 'Multimedia',
			'dgtSocialMedia'=> 'Social Media',
			'dgtIT' 		=> 'IT',
		],
		'Creative'	=> [
			'ctvArt'		=> 'Art',
			'ctvDraw'		=> 'Drawing',
			'ctvDance'		=> 'Dance',
			'ctvThretre'	=> 'Threter',
			'ctvMusic'		=> 'Music',
		],
		'Communication' => [
			'cmmMarket'			=>	'Market',
			'cmmMedia'			=>	'Media',
			'cmmPresentation'	=> 'Presentation',
		]
	];

	


	
	
	public static $SkillsetsCategory = [
		'lang' => 'Language',
		'mcr' => 'Microsoft',
		'pgr'=> 'Programming',
		'dsg'=>'Design',
		'edgn'=>'Engineering Design',
		'funding'=> 'Funding',
		'branding'=>'Branding',
		'dgt'=> 'Digital',
		'ctv'=>'Creative',
		'cmm'=>'Communication',
		'business'=>'Business',
		'entrepreneurship'=>'Entrepreneurship',
	];

	public static function GetProgrammes()
	{
		$programmes = Programme::select('code', 'name')->get();
		$ps = [];
		foreach($programmes as $i=>$p)
			$ps[$p->code] = $p->name;
		return $ps;
	}

	public static function GetValidProgrammes()
	{
		$programmes = Programme::select('code', 'name')
		->where('end_year',date('Y'))
		->where('end_month','>=',date('n'))
		->get();
		$ps = [];
		foreach($programmes as $i=>$p)
			$ps[$p->code] = $p->name;
		return $ps;
	}
	
	public static $OfficeworkCategory = [
		'1' => 'Design',
		'2' => 'Creative',
	];
	
	public static $OfficeworkDescription = 
	[
		'1' => 'Design logo for upcoming event.',
		'2' => 'Create arts for upcoming event.',
	];
	
	public static $NotificationCategory = [
		'1' => 'Normal',
		'2' => 'Announcement',
		'3' => 'Reminder',
		'4' => 'Urgent',
	];
	
	public static $NotificationDescription = 
	[
		'1' => 'Normal',
		'2' => 'Announcement',
		'3' => 'Reminder',
		'4' => 'Urgent',
	];
	
	public static $DataExportGuidance = 
	[
		'1' => 'Get the attendance list for upcoming event',
		'2' => 'Show the list of events a volunteer registered before',
		'3' => 'Show the list of events under a specific programme a volunteer registered before',
		'4' => 'Show the list of events a volunteer registered before within a period of time',
		'5' => 'Show the list of events under a specific programme a volunteer registered before within a period of time',
		'6' => 'Show the list of inactive volunteers',
		'7' => 'Show the list of most active volunteer of all time',
		'8' => 'Show the list of most active volunteer in this year'
	];
	
	public static $guidanceJson = [
		'0' => ['programmeName'=>false, 'eventName'=>false, 'date'=>false, 'volunteerName'=>false],
		'1' => ['programmeName'=>true, 'eventName'=>true, 'date'=>true, 'volunteerName'=>false],
		'2' => ['programmeName'=>false, 'eventName'=>false, 'date'=>false, 'volunteerName'=>true],
		'3' => ['programmeName'=>true, 'eventName'=>false, 'date'=>false, 'volunteerName'=>true],
		'4' => ['programmeName'=>false, 'eventName'=>false, 'date'=>true, 'volunteerName'=>true],
		'5' => ['programmeName'=>true, 'eventName'=>false, 'date'=>true, 'volunteerName'=>true],
		'6' => ['programmeName'=>false, 'eventName'=>false, 'date'=>false, 'volunteerName'=>false],
		'7' => ['programmeName'=>false, 'eventName'=>false, 'date'=>false, 'volunteerName'=>false],
		'8' => ['programmeName'=>false, 'eventName'=>false, 'date'=>false, 'volunteerName'=>false],
	];
	
	public static $ranks = [
		0 => 'Bronze',
		 50 => 'Bronze I',
		 100 => 'Bronze II',
		 150 => 'Bronze III',
		 200 => 'Bronze IV',
		 250 => 'Silver I',
		 300 => 'Silver II',
		 350 => 'Silver III',
		 400 => 'Silver IV',
		 450 => 'Gold I',
		 500 => 'Gold II',
		 550 => 'Gold III',
		 600 => 'Gold IV',
		 650 => 'Platinum I',
		 700 => 'Platinum II',
		 750 => 'Platinum III',
		 800 => 'Platinum IV',
		 850 => 'Diamond I',
		 900 => 'Diamond II',
		 950 => 'Diamond III',
		 1000 => 'Diamond IV',
		 1050 => 'Glory I',
		 1100 => 'Glory II',
		 1150 => 'Glory III',
		 1200 => 'Glory IV',
		 1250 => 'Glory V',
	];
	
	public static function getRank($hour)
	{
		try
		{
			$rank = Common::$ranks[intval($hour/50)*50];
		}
		catch(\Exception $e)
		{
			$rank = null;
		}
		finally
		{
			if($hour < 0)
				return $ranks[0];
			elseif($hour>1250)
				return $ranks[1250];
			return $rank;
		}
	}
	
	public static function getLifetimeServeHour()
	{
		return DB::select( DB::raw("
			select v.*, sum(serve_hour) as total_serve_hour
			from (
				select vid, serve_hour
				from volunteer_events 
				where serve_hour>0
				union all
				select vid, serve_hour
				from volunteer_officeworks
				where serve_hour > 0
			) as veo, volunteers as v
			where veo.vid = v.vid
			group by vid
			order by total_serve_hour desc
		") );
	}
	
	public static function getLifetimeServeHourVolunteer($vid)
	{
		return DB::select( DB::raw("
			select v.*, sum(serve_hour) as total_serve_hour
			from (
				select vid, serve_hour
				from volunteer_events 
				where serve_hour>0 and vid = '{$vid}'
				union all
				select vid, serve_hour
				from volunteer_officeworks
				where serve_hour > 0 and vid = '{$vid}'
			) as veo, volunteers as v
			where veo.vid = v.vid
			group by vid
			order by total_serve_hour desc
		") );
	}
	
	public static function getAnnualServeHour()
	{
		$year = Carbon::now()->year;
		return DB::select( DB::raw("
			select v.*, sum(serve_hour) as total_serve_hour
			from (
				select vid, ve.serve_hour
				from volunteer_events as ve, events as e
				where ve.eid = e.eid and 
				e.date >= '{$year}-01-01' and 
				e.date <= '{$year}-12-31' and 
				ve.serve_hour > 0
				union all
				select vid, serve_hour
				from volunteer_officeworks
				where serve_hour > 0
			) as veo, volunteers as v
			where veo.vid = v.vid
			group by vid
			order by total_serve_hour desc
		") );
	}
	
	public static function getAnnualServeHourVolunteer($vid)
	{
		$year = Carbon::now()->year;
		return DB::select( DB::raw("
			select v.*, sum(serve_hour) as total_serve_hour
			from (
				select vid, ve.serve_hour
				from volunteer_events as ve, events as e
				where ve.eid = e.eid and 
				vid = {$vid} and
				e.date >= '{$year}-01-01' and 
				e.date <= '{$year}-12-31' and 
				ve.serve_hour > 0
				union all
				select vid, serve_hour
				from volunteer_officeworks
				where serve_hour > 0 and vid = {$vid}
			) as veo, volunteers as v
			where veo.vid = v.vid
			group by vid
			order by total_serve_hour desc
		") );
	}
	
}
