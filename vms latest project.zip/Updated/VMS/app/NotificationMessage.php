<?php

namespace App;

class NotificationMessage
{
	/*
	Note: The line break at the start of each description is not a mistake.
	*/
	
	public static $notify_new_volunteer = [
		'title'			=>	"Someone had registered an account.",
		'description'	=>	"
		Please welcome %s for joining CyberCare.
		Click <a href='%s' target='_blank'>here</a> to visit the profile.",
	];
	
	public static $notify_new_event = [
		'title'			=>	"A new event, %s is available for reservation now!",
		'description'	=>	"
		If you are interested, please click <a href='%s' target='_blank'>here</a> to see more information about this event.",
	];
	
	public static $notify_edit_event = [
		'title'			=>	"The date and time of event, %s has been updated.",
		'description'	=>	"
		The event's date and time has been adjusted from %s to %s.
		Please click <a href='%s' target='_blank'>here</a> to see more information about this event.
		Sorry to cause any inconvenience.",
	];
	
	public static $notify_delete_event = [
		'title'			=>	"Event %s is removed.",
		'description'	=>	"
		Due to some issues, the event, %s has been removed. 
		Sorry to cause any inconvenience.",
	];
	
	public static $notify_new_programme = [
		'title'			=>	'New available %s Programme',
		'description'	=>	'
		A new programme named: %s is available now!.
		Everyone is welcome to take part in this programme.',
	];
	
	
	public static $notify_delete_programme = [
		'title'			=>	'%s Programme is Removed',
		'description'	=>	'
		The programme named: %s is removed due to some issues.
		You are welcome to take part in other programmes.',
	];
	
	public static $notify_reminder = [
		'title'			=>	"Just %s day%s until the event, %s kicks off!",
		'description'	=>	"
		An event you've reserved, %s will be held at %s.
		Please click <a href='%s' target='_blank'>here</a> to see more information about this event.",
	];
	
	public static $notify_milestone = [
		'title' => "Congratulation! You've reached %s rank",
		'description' => "
		According to the records, you've served for a total of %s hour!",
	];
}