<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Common;
use Illuminate\Http\Request;
use App\AdminAccount;
use App\VolunteerAccount;
use App\Volunteer;
use App\Event;
use App\Programme;
use App\ProgrammeImage;
use App\InterestedProgramme;
use App\Officework;
use App\Notification;
use App\AwardHistory;
use App\Skillset;
use App\VolunteerEvent;
use App\VolunteerNotification;
use App\VolunteerOfficework;

class MainController extends Controller
{
    public function award(Request $request){
		if(Session::get('authority')=='admin')
			return redirect()->route('home');
		
		$vid = Session::get('user_id');
		$volunteer_serve_hour = Common::getLifetimeServeHourVolunteer($vid)[0]->total_serve_hour;
		
		$rank = Common::getRank(floatval($volunteer_serve_hour));
		
        return view('award',[
            'volunteer_serve_hour' => $volunteer_serve_hour,
            'volunteer_rank' => $rank
        ]);
    }
   
	public function index(Request $request)
	{
        $programmes = Programme::all();
        $events = \DB::table('events')->where('date','>=',date('Y-m-d'))->get();
        foreach($programmes as $i => $programme){
            $number_of_events[$i] = count(\DB::table('events')->where('pid',$programme->pid)->get());
            $number_of_completed_events[$i] = count(\DB::table('events')->where('pid',$programme->pid)->where('date','<',date('Y-m-d'))->get());
            $number_of_ongoing_events[$i] = count(\DB::table('events')->where('pid',$programme->pid)->where('date','>=',date('Y-m-d'))->get());
        }

		//inactive volunteers
        $inactive_volunteer_count = count(Volunteer::where('last_active_date', '<', Carbon::now()->subDays(Common::$DAY_TO_CONSIDER_INACTIVE))
		->orderBy('last_active_date', 'asc')
		->get());
		
		//Number of volunteers in the database
		$volunteer_count = count(Volunteer::all());
		
		//Number of new volunteer registered this month
		$new_volunteer_this_month = count(Volunteer::whereMonth('created_at', '=', Carbon::today()->month)
		->get());

		$volunteer_acc_serve_hour = Common::getLifetimeServeHour();
		$volunteer_ann_serve_hour = Common::getAnnualServeHour();
		
		//next event
		//If admin, will show the next upcoming event
		//If volunteer, will show the next 5 upcoming event that they had reserve 
		
		if(Session::get('authority')=='admin')
		{
			$next_events = Event::join('programmes as p', 'p.pid', '=', 'events.pid')
			->select('p.code', 'events.*', \DB::raw('datediff(events.date, "'.Carbon::today().'") as date_diff'))
			->whereDate('events.date', '>', Carbon::today())
			->orderBy('start_time')
			->paginate(3);
		}
		elseif(Session::get('authority')=='volunteer')
		{
			$reserved_eids = VolunteerEvent::where('vid', Session::get('user_id'))->pluck('eid');
			$next_events = Event::join('programmes as p', 'p.pid', '=', 'events.pid')
			->whereIn('events.eid', $reserved_eids)
			->select('p.code', 'events.*', \DB::raw('datediff(events.date, "'.Carbon::today().'") as date_diff'))
			->whereDate('events.date', '>', Carbon::today())
			->orderBy('start_time')
			->paginate(3);
		}
		else
		{
			$next_events = null;
		}
		
        return view('/homepage',[
			"new_volunteer_this_month"	=>	$new_volunteer_this_month,
			"volunteer_count"			=>	$volunteer_count,
			"active_volunteer_count"	=>	$volunteer_count - $inactive_volunteer_count,
			"volunteer_acc_serve_hour"	=>	$volunteer_acc_serve_hour,
			"volunteer_ann_serve_hour"	=>	$volunteer_ann_serve_hour,
			"next_events"				=>	$next_events
        ]);
	}
	
}
