
@extends('master')
@section('container')
@if(\Session::has('user_id'))
@yield('content')
@else
<script>
 window.location.href = '{{route("auth")}}';
</script>
@endif
@endsection