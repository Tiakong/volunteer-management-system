<?php
use App\Common;
?>
@extends('notification.master', ['title'=>'Notification Detail'])

@section('content')
<div class='text-center col-sm-12'>
	<br/>
	@include('common.show-error')
	<br/>
	<div class='p-5 text-right'>
		<div class="form-group row">
			{!! Form::label('notification-title', 'Title', [
				'class' => 'control-label col-sm-2',
			]) !!}
			<div class='col-sm-10 text-left'>
				<p><?php echo $notification->title?></p>
			</div>
		</div>
		<div class="form-group row">
			{!! Form::label('notification-description', 'Description', [
				'class' => 'control-label col-sm-2',
			]) !!}
			<div class='col-sm-10 text-left'>
				<pre><?php echo $notification->description?>
				</pre>
			</div>
		</div>
		<div class="form-group row">
			{!! Form::label('employee-name', 'Category', [
				'class' => 'control-label col-sm-2',
			]) !!}
			<div class='col-sm-10 text-left'>
				<p>{{Common::$NotificationCategory[$notification->category]}}</p>
			</div>
		</div>
		<div class="form-group row">
			{!! Form::label('employee-name', 'Created by', [
				'class' => 'control-label col-sm-2',
			]) !!}
			<div class='col-sm-10 text-left'>
				<p>{{$notification->created_by}}</p>
			</div>
		</div>
	</div>
	
	<div class="form-group row text-center">
        <div class="col-sm-offset-3 col-sm-6">
			<a href="{{route('notification.index')}}">
				<button class="btn btn-lg btn-primary" ><i class='fa fa-reply'></i> Back</button>
			</a>
		
		@if(\Session::get('authority') == 'admin')
		
			<a href="{{route('notification.edit', $notification->nid)}}">
				<button type='button' class="btn btn-lg btn-success"><i class='fa fa-edit'></i> Edit</button>
			</a>
			<a>
				<button type='button' class="btn btn-lg btn-danger"onclick='return ConfirmDelete("<?php echo route("notification.delete", $notification->nid)?>")'><i class='fa fa-remove'></i> Delete</button>
			</a>
		</div>
		@endif
	</div>
</div>
</div>

@endsection