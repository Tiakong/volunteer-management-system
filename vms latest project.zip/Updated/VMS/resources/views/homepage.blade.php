<?php
use Carbon\Carbon;
?>

@extends('master', ['title'=>'Welcome to Volunteer Management System'])
@section('container')
@if(Session::get('authority')=='volunteer' || Session::get('authority')=='admin')
<div class="content">
	<div class="left-section">
		@if(Session::get('authority')=='admin')
		<!-- Active & Non Active Volunteer Count -->
		<div class="main-section">
			<div style='width:400px'>
				<div>
					<h1><i class="fa fa-address-book-o" style="margin-right: 10px;color:black;"></i>Volunteers Statistic</h1>
					<table class="table table-stripped table-bordered">
						<col width="80%">
						<col width="20%">
						<thead class='thead-dark'>
							<tr>
								<th>Number of Volunteers</th>
								<td>{{$volunteer_count}}</td>
							</tr>
							<tr>
								<th>Active Volunteers</th>
								<td>{{$active_volunteer_count}}</td>
							</tr>
							<tr>
								<th>New Volunteer Registered this month</th>
								<td>{{$new_volunteer_this_month}}</td>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
		@endif
		<!-- Next upcoming event -->
		<div class="main-section">
			<div class="ranking-section">
				<div>
					<h1><i class="fa fa-list-alt" style="margin-right: 10px;color:black;"></i>Next Upcoming Event</h1>
					<table class="table table-stripped table-bordered">
						<col width="10%">
						<col width="28%">
						<col width="18%">
						<col width="18%">
						<col width="16%">
						<col width="15%">
						<thead class='thead-dark'>
							<tr>
								<th>Programme</th>
								<th>Event Name</th>
								<th>Date</th>
								<th>Time</th>
								<th>Day Left</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							@if(count($next_events)==0)
							<tr>
								<th colspan=4>No event</th>
							</tr>
							@else
								@foreach($next_events as $next_event)
							<tr>
								<th>{{$next_event->code}}</th>
								<th>{{$next_event->name}}</th>
								<th>{{$next_event->date}}</th>
								<th>{{Carbon::parse($next_event->start_time)->format('h:i a')}} <br> ~ <br> {{Carbon::parse($next_event->end_time)->format('h:i a')}}</th>
								<th>{{$next_event->date_diff}}</th>
								<th><a href="{{route('event.show-detail', $next_event->eid)}}">See More</a></th>
							</tr>
								@endforeach
							@endif
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div class='right-section text-center'>
        <div class="ranking-section">
			<div class="main-section-content">
				<!-- Life time serving -->
				<div>
					<h1><i class="fa fa-trophy" style="margin-right: 10px;color:black;"></i>Cybercare Leaderboard</h1>
					<table class='table table-stripped table-bordered'>
						<col width="">
						<thead class='thead-dark'>
							<tr>
								<th>Ranking</th>
								<th>Name</th>
								<th>Occupation</th>
								<th>Total Serve hour</th>
							</tr>
						</thead>
						<tbody>
							@foreach($volunteer_acc_serve_hour as $row)
							<tr>
								<td class='text-center'>{{$loop->index+1}}</td>
								<td>{{$row->name}}</td>
								<td>{{$row->occupation}}</td>
								<td class='text-center'>{{$row->total_serve_hour}}</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
				
				<!-- Annual serving -->
				<div>
					<h1><i class="fa fa-trophy" style="margin-right: 	10px;color:black;"></i>Annual Leaderboard({{date('Y')}})</h1>
					<table class='table table-stripped table-bordered'>
						<col width="">
						<thead class='thead-dark'>
							<tr>
								<th>Ranking</th>
								<th>Name</th>
								<th>Occupation</th>
								<th>Total Serve hour</th>
							</tr>
						</thead>
						<tbody>
							@foreach($volunteer_ann_serve_hour as $row)
							<tr>
								<td class='text-center'>{{$loop->index+1}}</td>
								<td>{{$row->name}}</td>
								<td>{{$row->occupation}}</td>
								<td class='text-center'>{{$row->total_serve_hour}}</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@else
<script>
 window.location.href = '{{route("auth")}}';
</script>
@endif
@endsection