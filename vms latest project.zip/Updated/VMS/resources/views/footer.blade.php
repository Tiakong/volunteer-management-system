<div class="cybercare-footer">
    <p id="copyright">© 2018 CyberCare Youth Organisation Be Inspired - Get Empowered - Be The Change</p>
    <ul class="right-info hidden-xs" id="footer-sm">
        <li><a href="https://plus.google.com/105938260003540934580" target="_blank"><i class="fa fa-google-plus"  style="font-size:15px; color:rgb(248, 248, 248);"></i></a></li>
        <li><a href="https://www.instagram.com/cybercare_youth/" target="_blank"><i class="fa fa-instagram"  style="font-size:15px; color:rgb(248, 248, 248);"></i></a></li>
        <li><a href="https://twitter.com/CyberCare_Youth" target="_blank"><i class="fa fa-twitter"  style="font-size:15px; color:rgb(248, 248, 248);"></i></a></li>
        <li><a href="https://www.facebook.com/CyberCareKL" target="_blank"><i class="fa fa-facebook"  style="font-size:15px; color:rgb(248, 248, 248);"></i></a></li>
    </ul>
</div>