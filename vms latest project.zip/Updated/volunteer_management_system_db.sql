-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 18, 2019 at 09:12 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volunteer_management_system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

DROP TABLE IF EXISTS `admin_accounts`;
CREATE TABLE IF NOT EXISTS `admin_accounts` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`username`, `password`, `created_at`, `updated_at`) VALUES
('cybercare', '$2y$10$2kFuiD.ySzmJZOYNJb.I6OW3gFJbMgBFZqFxcw81PiqHEzaa99NqO', '2019-06-30 08:00:00', '2019-06-30 08:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `eid` char(36) NOT NULL,
  `pid` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `venue` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `serve_hour` decimal(3,1) NOT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`eid`),
  KEY `events_pid_foreign` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `has_send_reminder`
--

DROP TABLE IF EXISTS `has_send_reminder`;
CREATE TABLE IF NOT EXISTS `has_send_reminder` (
  `eid` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `interested_programmes`
--

DROP TABLE IF EXISTS `interested_programmes`;
CREATE TABLE IF NOT EXISTS `interested_programmes` (
  `vid` char(36) NOT NULL,
  `pid` char(36) NOT NULL,
  PRIMARY KEY (`vid`,`pid`),
  KEY `interested_programmes_pid_foreign` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interested_programmes`
--

INSERT INTO `interested_programmes` (`vid`, `pid`) VALUES
('fe673b5c-e5a4-42cb-93f0-8d4df2c238f6', '5f18e75c-854b-4fed-a9e0-6c1f98d786ac');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(194, '2019_07_20_185241_create_programme_images_table', 2),
(193, '2019_07_20_102808_create_notifications_table', 2),
(182, '2019_07_01_031259_create_volunteers_table', 2),
(183, '2019_07_01_031937_create_events_table', 2),
(184, '2019_07_01_032144_create_officeworks_table', 2),
(157, '2019_07_01_032211_create_award_histories_table', 1),
(185, '2019_07_01_032204_create_skillsets_table', 2),
(186, '2019_07_01_032218_create_volunteer_accounts_table', 2),
(187, '2019_07_01_032224_create_admin_accounts_table', 2),
(188, '2019_07_01_032231_create_volunteer_events_table', 2),
(189, '2019_07_01_032237_create_volunteer_officeworks_table', 2),
(190, '2019_07_01_032244_create_volunteer_notifications_table', 2),
(191, '2019_07_01_032255_create_programmes_table', 2),
(192, '2019_07_06_021516_create_interested_programmes_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `nid` char(36) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `category` varchar(100) NOT NULL,
  `for_volunteer` tinyint(1) NOT NULL DEFAULT '1',
  `for_admin` tinyint(1) NOT NULL DEFAULT '1',
  `broadcast` tinyint(1) NOT NULL DEFAULT '0',
  `is_auto` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(100) NOT NULL DEFAULT 'CyberCare system',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `officeworks`
--

DROP TABLE IF EXISTS `officeworks`;
CREATE TABLE IF NOT EXISTS `officeworks` (
  `oid` char(36) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `serve_hour` decimal(3,1) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `programmes`
--

DROP TABLE IF EXISTS `programmes`;
CREATE TABLE IF NOT EXISTS `programmes` (
  `pid` char(36) NOT NULL,
  `code` varchar(6) NOT NULL,
  `venue` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `target` varchar(50) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `start_month` int(2) NOT NULL,
  `end_month` int(2) NOT NULL,
  `start_year` varchar(4) NOT NULL,
  `end_year` varchar(4) NOT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `programmes`
--

INSERT INTO `programmes` (`pid`, `code`, `venue`, `name`, `description`, `target`, `contact`, `start_month`, `end_month`, `start_year`, `end_year`, `created_by`) VALUES
('5553fd31-26df-4294-b040-425a60b30987', 'STEP', 'Klang Valley', 'Self-empowering and Transition Employability Programme', 'Change happens fast in the world of work, driven by innovation and by developments in technology and markets. The active participation of employers’ and workers’ representatives in vocational education and training institutions is essential to bridging this gulf (International Labour Force, November 2010).\r\n\r\nRecognising the importance of vocational training and competency in soft skills to increase employability, STEP incorporates a mixture of classroom sessions and workplace challenges to support underprivileged youth aged 16 and above to make informed career-related decisions, in preparation for independence adulthood.', 'Youth aged 16 and above', '0133652027', 3, 6, '2019', '2019', 'Alex'),
('4d59dd70-a76d-4915-b62c-be30f20554f1', 'YEP', 'Klang Valley', 'Youth Entrepreneurship Programme', 'Youth entrepreneurship is important in addressing high unemployment (approximately twice the adult rate). Young people are more likely to prefer self-employment than adults (OECD and the European Commission, September 2014).\r\n\r\nOver a 3-month period, YEP endeavors to instill an entrepreneurial mindset in youth aged 18 and above by equipping them with life skills to be self-sustaining members of society.', 'Youth aged 18 and above (SPM-holders)', '0133652027', 1, 4, '2019', '2019', 'James'),
('2a1b74ff-ab9e-4db4-921d-72f8def6e0d3', 'CMP', 'Centrestage, Petaling Jaya', 'Change Makers’ Project', 'CyberCare’s programmes have been carefully designed to ensure the youth achieve the best possible outcome, be it increasing their employability skills or growing their business acumen. To ensure sustainability and growth, CMP was incepted to help nurture and empower a new generation of trainers to run our programmes.\r\n\r\nWe invite individuals who are interested to support and coach youth as part of their personal or professional calling to join us on this meaningful journey.', 'Recommended aged 25 and above', '0133652027', 3, 8, '2019', '2019', 'Nick');

-- --------------------------------------------------------

--
-- Table structure for table `programme_images`
--

DROP TABLE IF EXISTS `programme_images`;
CREATE TABLE IF NOT EXISTS `programme_images` (
  `id` char(36) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `pid` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `programme_images_pid_foreign` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `skillsets`
--

DROP TABLE IF EXISTS `skillsets`;
CREATE TABLE IF NOT EXISTS `skillsets` (
  `vid` char(36) NOT NULL,
  `langEN` tinyint(4) NOT NULL DEFAULT '0',
  `langZH` tinyint(4) NOT NULL DEFAULT '0',
  `langMS` tinyint(4) NOT NULL DEFAULT '0',
  `langHI` tinyint(4) NOT NULL DEFAULT '0',
  `mcrWord` tinyint(4) NOT NULL DEFAULT '0',
  `mcrExcel` tinyint(4) NOT NULL DEFAULT '0',
  `mcrPowerPoint` tinyint(4) NOT NULL DEFAULT '0',
  `pgrCpp` tinyint(4) NOT NULL DEFAULT '0',
  `pgrJs` tinyint(4) NOT NULL DEFAULT '0',
  `pgrPhp` tinyint(4) NOT NULL DEFAULT '0',
  `pgrSql` tinyint(4) NOT NULL DEFAULT '0',
  `pgrPython` tinyint(4) NOT NULL DEFAULT '0',
  `dsgPhotoshop` tinyint(4) NOT NULL DEFAULT '0',
  `dsgIllustrator` tinyint(4) NOT NULL DEFAULT '0',
  `dsgPremiumPro` tinyint(4) NOT NULL DEFAULT '0',
  `edgnAutocad` tinyint(4) NOT NULL DEFAULT '0',
  `edgnSolidWorks` tinyint(4) NOT NULL DEFAULT '0',
  `dgtIT` tinyint(1) NOT NULL DEFAULT '0',
  `dgtMultimedia` tinyint(1) NOT NULL DEFAULT '0',
  `dgtSocialMedia` tinyint(1) NOT NULL DEFAULT '0',
  `ctvArt` tinyint(1) NOT NULL DEFAULT '0',
  `ctvDraw` tinyint(1) NOT NULL DEFAULT '0',
  `ctvDance` tinyint(1) NOT NULL DEFAULT '0',
  `ctvThretre` tinyint(1) NOT NULL DEFAULT '0',
  `ctvMusic` tinyint(1) NOT NULL DEFAULT '0',
  `cmmMarket` tinyint(1) NOT NULL DEFAULT '0',
  `cmmMedia` tinyint(1) NOT NULL DEFAULT '0',
  `cmmPresentation` tinyint(1) NOT NULL DEFAULT '0',
  `funding` tinyint(1) NOT NULL DEFAULT '0',
  `branding` tinyint(1) NOT NULL DEFAULT '0',
  `business` tinyint(1) NOT NULL DEFAULT '0',
  `entrepreneurship` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

DROP TABLE IF EXISTS `volunteers`;
CREATE TABLE IF NOT EXISTS `volunteers` (
  `vid` char(36) NOT NULL,
  `id` varchar(8) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `nric` varchar(14) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_no` varchar(16) NOT NULL,
  `race` varchar(50) NOT NULL,
  `gender` char(1) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `address` varchar(300) NOT NULL,
  `education_level` varchar(100) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `t_shirt_size` char(2) NOT NULL,
  `em_person` varchar(100) NOT NULL,
  `em_contact_no` varchar(16) NOT NULL,
  `em_relation` varchar(100) NOT NULL,
  `last_active_date` date NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `acc_serve_hour` double DEFAULT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_accounts`
--

DROP TABLE IF EXISTS `volunteer_accounts`;
CREATE TABLE IF NOT EXISTS `volunteer_accounts` (
  `vid` char(36) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_events`
--

DROP TABLE IF EXISTS `volunteer_events`;
CREATE TABLE IF NOT EXISTS `volunteer_events` (
  `vid` char(36) NOT NULL,
  `eid` char(36) NOT NULL,
  `status` char(255) NOT NULL,
  `remark` varchar(300) NOT NULL,
  `serve_hour` decimal(3,1) NOT NULL,
  PRIMARY KEY (`vid`,`eid`),
  KEY `volunteer_events_eid_foreign` (`eid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_notifications`
--

DROP TABLE IF EXISTS `volunteer_notifications`;
CREATE TABLE IF NOT EXISTS `volunteer_notifications` (
  `vid` char(36) NOT NULL,
  `nid` char(36) NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`vid`,`nid`),
  KEY `volunteer_notifications_nid_foreign` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_officeworks`
--

DROP TABLE IF EXISTS `volunteer_officeworks`;
CREATE TABLE IF NOT EXISTS `volunteer_officeworks` (
  `vid` char(36) NOT NULL,
  `oid` char(36) NOT NULL,
  `remark` varchar(300) NOT NULL,
  `serve_hour` decimal(3,1) NOT NULL,
  PRIMARY KEY (`vid`,`oid`),
  KEY `volunteer_officeworks_oid_foreign` (`oid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
